// contar de 0 ate o num informado
// e do num informado ate 0

i=0
// usuario informou
usuario =10

while(i < usuario){
    console.log(i)
    i++
}
// i--
while(i>0){
    console.log(i)
    i--
}


