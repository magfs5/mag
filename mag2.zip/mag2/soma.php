<?php

function soma($a,$b){
    echo $a +$b;
}

function soma2($numero1, $numero2){
    return($numero1+ $numero2);
}


$a = 1;
$b = 2;

$resultado=soma($a,$b);
echo $resultado

// echo $a + $b;

?>