// completar ate 100
// partir do numero que o usuario digitar


i = 50


while(i<=100){
    console.log(i)
    i--

}




