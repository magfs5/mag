lista = ["café","açucar", "mateiga","pao"]
