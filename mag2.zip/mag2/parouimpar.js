// verificar se o número é par ou ímpar
numero = 10

numero/2

// operador que pega o resto -> módulo %
resto = numero % 2
// se(pergunta;respostaverdadeira;resposta falsa)
if(resto==0){
    console.log('o numero é par')
}
else{
    console.log('onumero é impar')
}
// console.log(resto)


// em mátemática módulo retira o sinal do número
// em comp -> absoluto ->abs()
