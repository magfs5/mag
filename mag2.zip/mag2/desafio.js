// senha para ordem de chegada exame

i= 0
pessoas= 50


while(i<=pessoas){
    console.log(i)
    i++
}

 