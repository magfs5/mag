// irá digitar a sua idade e,
// caso a idade seja a maior ou igual a 18,
// terá como resposta "maior de idade".
// caso contrário,"menor de Idade"

idade = 22

if (idade>=18){
    console.log('maior de idade')

}
else{
    console.log('menor de idade')
}
