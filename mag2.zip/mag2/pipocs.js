a=5
b='5'

console.log(a==b)

console.log(a==b)
